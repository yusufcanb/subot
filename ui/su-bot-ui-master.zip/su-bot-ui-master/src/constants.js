export const API_BASE_URL = process.env.NODE_ENV === "development" ? "http://subot.perga.co/api" : "/api";
export const SESSION_EXPIRE_MS = 60 * 1000; // in miliseconds

